BASE DE DATOS - SISTEMA WEB DE VOTACIÓN

Motor: PostgreSQL

1. Crear la base:
   CREATE DATABASE votacion_db;

2. Ejecutar la estructura:
   psql -U postgres -d votacion_db -f schema.sql

3. Cargar datos de demostración:
   psql -U postgres -d votacion_db -f seed.sql

Tablas:
- usuarios
- elecciones
- candidatos
- votos

Control de integridad principal:
UNIQUE(usuario_id, eleccion_id)
Impide que un usuario registre más de un voto en la misma elección.
